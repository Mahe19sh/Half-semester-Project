import axios from 'axios';
import { useEffect, useState } from 'react';
import { Container } from 'react-bootstrap';
import { useSearchParams } from 'react-router-dom';
import GroceryItem from './grocery-item';
import HomeNavbar from './homeNavbar';
import OffersCorousel from './offers-corousel';

export default function Home() {
    const [groceryItems, setGroceryItems] = useState([]);
    let [searchParams, setSearchParams] = useSearchParams();

    useEffect(() => {
        const categoryId = searchParams.get('categoryId');

        let url = 'http://localhost:8080/groceries'
        if (categoryId) {
            url = url + '?categoryId=' + categoryId;
        }

        axios
          .get(url)
          .then((response) => {
              console.log(response.data);
              setGroceryItems(response.data);
          })
    }, []);

    return (
      <div>
          <HomeNavbar/>
          <OffersCorousel/>
          <Container style={style} fluid={true}>
              { groceryItems.map((item,index)=> {
                  return <GroceryItem item={item}/>
              })}
          </Container>
      </div>
    )
}

const style = {
    display: "flex",
    flexWrap: "wrap"
};
