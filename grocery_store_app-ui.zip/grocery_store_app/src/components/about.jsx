export default function About() {
    return (
      <div>Grocery Store is one of the best place to buy Groceries</div>
    )
}
