import axios from 'axios';
import { useState } from 'react';
import { Alert, Form } from 'react-bootstrap';
import Button from 'react-bootstrap/Button';
import { useNavigate } from 'react-router-dom';
import PreLoginNavbar from './preloginNavbar';

export default function Signup() {
    const [firstName, setFirstName] = useState("");
    const [lastName, setLastName] = useState("");
    const [mailId, setMailId] = useState("");
    const [userName, setUserName] = useState("");
    const [password, setPassword] = useState("");
    const [phoneNumber, setPhoneNumber] = useState("");
    const [address, setAddress] = useState("");

    const [validated, setValidated] = useState(false);
    const [error, setError]= useState("");

    const navigate = useNavigate();

    const onRegister = (event) => {
        event.preventDefault();
        event.stopPropagation();

        setValidated(true);

        const form = event.currentTarget;
        if (form.checkValidity() === false) {
            return;
        }

        axios
          .post("http://localhost:8080/signup", {
              email: mailId,
              password: password,
              firstName: firstName,
              lastName: lastName,
              userName: userName,
              phone: phoneNumber,
              address: address
          })
          .then((response) => {
              navigate('/home');
          }, (err) => {
              setError(err.response.data.message);
          });

    };

    return (
      <div>
      <PreLoginNavbar/>
          { error ?
            <Alert key={'danger'} variant={'danger'} style={{margin: '20px'}}>
                {error}
            </Alert> : <></>
          }

          <Form style={containerStyle} noValidate validated={validated} onSubmit={onRegister}>
              <Form.Group  md="4" controlId="firstName">
                  <Form.Label>First name</Form.Label>
                  <Form.Control
                    required
                    type="text"
                    placeholder="Fist Name"
                    value={firstName}
                    onChange={(e) => setFirstName(e.target.value)}
                  />
                  <Form.Control.Feedback type="invalid">Please provide proper first name</Form.Control.Feedback>
              </Form.Group>

              <Form.Group  md="4" controlId="lastName" style={groupStyle}>
                  <Form.Label>Last name</Form.Label>
                  <Form.Control
                    required
                    type="text"
                    placeholder="Last name"
                    value={lastName}
                    onChange={(e) => setLastName(e.target.value)}
                  />
                  <Form.Control.Feedback type="invalid">Please provide proper email</Form.Control.Feedback>
              </Form.Group>

              <Form.Group  md="4" controlId="email" style={groupStyle}>
                  <Form.Label>Email</Form.Label>
                  <Form.Control
                    required
                    type="email"
                    placeholder="Email"
                    value={mailId}
                    onChange={(e) => setMailId(e.target.value)}
                  />
                  <Form.Control.Feedback type="invalid">Please provide proper email</Form.Control.Feedback>
              </Form.Group>

              <Form.Group  md="4" controlId="username" style={groupStyle}>
                  <Form.Label>Username</Form.Label>
                  <Form.Control
                    required
                    type="text"
                    placeholder="Username"
                    value={userName}
                    onChange={(e) => setUserName(e.target.value)}
                  />
                  <Form.Control.Feedback type="invalid">Please provide proper email</Form.Control.Feedback>
              </Form.Group>

              <Form.Group  md="4" controlId="password" style={groupStyle}>
                  <Form.Label>Password</Form.Label>
                  <Form.Control
                    required
                    type="password"
                    placeholder="Password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                  />
                  <Form.Control.Feedback type="invalid">Please provide proper password</Form.Control.Feedback>
              </Form.Group>

              <Form.Group md="4" controlId="phone" style={groupStyle}>
                  <Form.Label>Phone</Form.Label>
                  <Form.Control
                    required
                    type="number"
                    placeholder="Phone"
                    value={phoneNumber}
                    onChange={(e) => setPhoneNumber(e.target.value)}
                  />
                  <Form.Control.Feedback type="invalid">Please provide proper phone</Form.Control.Feedback>
              </Form.Group>

              <Form.Group md="4" controlId="address" style={groupStyle}>
                  <Form.Label>Address</Form.Label>
                  <Form.Control
                    required
                    type="text"
                    placeholder="Address"
                    value={address}
                    onChange={(e) => setAddress(e.target.value)}
                  />
                  <Form.Control.Feedback type="invalid">Please provide proper address</Form.Control.Feedback>
              </Form.Group>

              <Button type="submit" style={groupStyle}>Signup</Button>
          </Form>
      </div>
    )
}

const groupStyle = {
    'margin-top': '20px'
}

const containerStyle = {
    'width': '400px',
    'margin': 'auto',
    'display': 'flex',
    'flexDirection': 'column',
    'paddingTop': '100px',
    'paddingBottom': '100px'
}
