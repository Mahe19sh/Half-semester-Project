import axios from 'axios';
import { useEffect, useState } from 'react';
import { Container } from 'react-bootstrap';
import toast from 'react-simple-toasts';
import GroceryItem from './grocery-item';
import HomeNavbar from './homeNavbar';

export default function Wishlist() {
    const [wishList, setWishList] = useState([]);

    useEffect(() => {
        axios
          .get('http://localhost:8080/wishlist')
          .then((response) => {
              setWishList(response.data);
          }, (err) => {
              toast(err.response.data.message);
          })
    }, []);

    function removeFromWishlist(item) {
        axios
          .get('http://localhost:8080/wishlistDelete?wishlistItemId='+item.id)
          .then((response) => {
              toast('Removed from wishlist')
              setWishList(response.data);
          }, (err) => {
              toast(err.response.data.message);
          })
    }

    return (
      <div>
          <HomeNavbar/>
          <div style={wishlistStyle}>
             Your wishlist:
          </div>
          <Container style={style} fluid={true}>
              { wishList.map((item,index)=> {
                  return <GroceryItem item={item.item} wishlistItem={item} removeFromWishlist={removeFromWishlist}/>
              })}
          </Container>
      </div>
    )
}

const wishlistStyle = {
    fontWeight: 'bolder',
    fontSize: '20px',
    padding: '20px'
};

const style = {
    display: "flex",
    flexWrap: "wrap"
};
