import axios from 'axios';
import { useEffect, useState } from 'react';
import { Container } from 'react-bootstrap';
import Card from 'react-bootstrap/Card';
import { FaArrowLeft } from 'react-icons/fa';
import { useNavigate } from 'react-router-dom';
import toast from 'react-simple-toasts';
import GroceryCartItem from './grocery-cart-item';
import HomeNavbar from './homeNavbar';
import Payment from './payment';

export default function Cart() {
    const [cartItems, setCartItems] = useState([]);

    const navigate = useNavigate();

    useEffect(() => {
        axios
          .get('http://localhost:8080/cart')
          .then((response) => {
              setCartItems(response.data);
          })
    }, []);

    function decrementCart(cartItem) {
        if (cartItem.quantity > 1) {
            axios
              .get('http://localhost:8080/cartDecrement?cartItemId='+cartItem.id)
              .then((response) => {
                  setCartItems(response.data);
                  toast('Reduced cart item quantity')
              })
        } else {
            axios
              .get('http://localhost:8080/cartDelete?cartItemId='+cartItem.id)
              .then((response) => {
                  setCartItems(response.data);
                  toast('Deleted cart item')
              })
        }
    }

    function incrementCart(cartItem) {
        axios
          .get('http://localhost:8080/cartIncrement?cartItemId='+cartItem.id)
          .then((response) => {
              setCartItems(response.data);
              toast('Increased cart item quantity')
          })
    }

    function getTotalPrice() {
        let totalCost = 0
        cartItems.forEach((cartItem) => {
            totalCost += (cartItem.item.price * cartItem.quantity);
        })
        return totalCost;
    }

    function orderItems(meta) {
        if (meta.erroredInputs.cardNumber
          || meta.erroredInputs.expiryDate
          || meta.erroredInputs.cvc) {
            return;
        }

        const items = [];

        cartItems.forEach((cartItem) => {
            items.push({
                item: cartItem.item.id,
                quantity: cartItem.quantity
            })
        })

        axios
          .post("http://localhost:8080/createOrder", {
              items
          })
          .then((response) => {
            toast('Successfully placed the order!');
            navigate('/home')
          })
    }

    return (
      <div>
      <HomeNavbar/>
      <a  style={backContainerStyle} href="/">
          <FaArrowLeft/>
          <div style={backTextStyle}>Back to shopping</div>
      </a>
      <Container style={cartContainer}>
          <div style={{width: '70em'}}>
            <div style={style} fluid={true}>
              { cartItems.map((item,index)=> {
                  return <GroceryCartItem cartItem={item} incrementCart={incrementCart} decrementCart={decrementCart} />
              })}
            </div>
          </div>
          <Card style={{width: '30em', margin: '1em'}}>
              <Card.Body>
                  <h4 style={{marginBottom: '2em'}}>Summary</h4>

                  <p><b>Total price:</b> ${getTotalPrice()} </p>
                  <p><b>Shipping:</b> Free</p>

                  <div style={{marginTop: '2em'}}>
                    <Payment orderItems={orderItems}/>
                  </div>
              </Card.Body>
          </Card>
      </Container>
      </div>
    )
}

const cartContainer = {
    display: 'flex',
    flexDirection: 'row'
}

const style = {
    display: "flex",
    flexDirection: 'column'
};

const backContainerStyle = {
    display: 'flex',
    lineHeight: '20px',
    padding: '20px',
    textDecoration: 'none'
}

const backTextStyle = {
    display: 'flex',
    lineHeight: '16px',
    fontSize: '20px',
    marginLeft: '5px',
    fontWeight: 'bold'
}
